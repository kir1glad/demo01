# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'login_formdSXHmm.ui'
##
## Created by: Qt User Interface Compiler version 6.10.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFormLayout, QLabel, QLineEdit,
    QMainWindow, QMenuBar, QPushButton, QSizePolicy,
    QStatusBar, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.btn_exit = QPushButton(self.centralwidget)
        self.btn_exit.setObjectName(u"btn_exit")
        self.btn_exit.setGeometry(QRect(700, 20, 80, 23))
        self.lbl_name = QLabel(self.centralwidget)
        self.lbl_name.setObjectName(u"lbl_name")
        self.lbl_name.setGeometry(QRect(300, 210, 181, 20))
        font = QFont()
        font.setFamilies([u"OpenSymbol"])
        font.setPointSize(12)
        font.setBold(True)
        font.setItalic(False)
        self.lbl_name.setFont(font)
        self.lbl_name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.formLayoutWidget = QWidget(self.centralwidget)
        self.formLayoutWidget.setObjectName(u"formLayoutWidget")
        self.formLayoutWidget.setGeometry(QRect(290, 260, 231, 83))
        self.formLayout = QFormLayout(self.formLayoutWidget)
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.lbl_login = QLabel(self.formLayoutWidget)
        self.lbl_login.setObjectName(u"lbl_login")

        self.formLayout.setWidget(0, QFormLayout.ItemRole.LabelRole, self.lbl_login)

        self.lbl_password = QLabel(self.formLayoutWidget)
        self.lbl_password.setObjectName(u"lbl_password")

        self.formLayout.setWidget(1, QFormLayout.ItemRole.LabelRole, self.lbl_password)

        self.line_login = QLineEdit(self.formLayoutWidget)
        self.line_login.setObjectName(u"line_login")

        self.formLayout.setWidget(0, QFormLayout.ItemRole.FieldRole, self.line_login)

        self.line_password = QLineEdit(self.formLayoutWidget)
        self.line_password.setObjectName(u"line_password")

        self.formLayout.setWidget(1, QFormLayout.ItemRole.FieldRole, self.line_password)

        self.btn_login = QPushButton(self.formLayoutWidget)
        self.btn_login.setObjectName(u"btn_login")

        self.formLayout.setWidget(2, QFormLayout.ItemRole.LabelRole, self.btn_login)

        self.btn_guest = QPushButton(self.formLayoutWidget)
        self.btn_guest.setObjectName(u"btn_guest")

        self.formLayout.setWidget(2, QFormLayout.ItemRole.FieldRole, self.btn_guest)

        self.label = QLabel(self.centralwidget)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(330, 80, 131, 111))
        self.label.setPixmap(QPixmap(u"img/Icon.png"))
        self.label.setScaledContents(True)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 20))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.btn_exit.setText(QCoreApplication.translate("MainWindow", u"\u0412\u044b\u0445\u043e\u0434", None))
        self.lbl_name.setText(QCoreApplication.translate("MainWindow", u"\u041e\u041e\u041e \u041e\u0431\u0443\u0432\u044c", None))
        self.lbl_login.setText(QCoreApplication.translate("MainWindow", u"\u041b\u043e\u0433\u0438\u043d:", None))
        self.lbl_password.setText(QCoreApplication.translate("MainWindow", u"\u041f\u0430\u0440\u043e\u043b\u044c:", None))
        self.btn_login.setText(QCoreApplication.translate("MainWindow", u"\u0412\u043e\u0439\u0442\u0438", None))
        self.btn_guest.setText(QCoreApplication.translate("MainWindow", u"\u0412\u043e\u0439\u0442\u0438 \u043a\u0430\u043a \u0433\u043e\u0441\u0442\u044c", None))
        self.label.setText("")
    # retranslateUi

