# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'product_formeNcRlk.ui'
##
## Created by: Qt User Interface Compiler version 6.10.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################
    
from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QLabel, QLineEdit,
    QMainWindow, QMenuBar, QPushButton, QScrollArea,
    QSizePolicy, QStatusBar, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(900, 600)
        MainWindow.setStyleSheet(u"background-color: rgb(246, 245, 244);\n"
"color: rgb(0, 0, 0);")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.btn_exit = QPushButton(self.centralwidget)
        self.btn_exit.setObjectName(u"btn_exit")
        self.btn_exit.setGeometry(QRect(800, 10, 80, 23))
        self.lbl_full_name = QLabel(self.centralwidget)
        self.lbl_full_name.setObjectName(u"lbl_full_name")
        self.lbl_full_name.setGeometry(QRect(490, 10, 291, 21))
        font = QFont()
        font.setFamilies([u"OpenSymbol"])
        font.setPointSize(12)
        font.setBold(True)
        self.lbl_full_name.setFont(font)
        self.lbl_full_name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.btn_add = QPushButton(self.centralwidget)
        self.btn_add.setObjectName(u"btn_add")
        self.btn_add.setGeometry(QRect(10, 110, 80, 23))
        self.btn_edit = QPushButton(self.centralwidget)
        self.btn_edit.setObjectName(u"btn_edit")
        self.btn_edit.setGeometry(QRect(100, 110, 80, 23))
        self.btn_del = QPushButton(self.centralwidget)
        self.btn_del.setObjectName(u"btn_del")
        self.btn_del.setGeometry(QRect(190, 110, 80, 23))
        self.lbl_search = QLabel(self.centralwidget)
        self.lbl_search.setObjectName(u"lbl_search")
        self.lbl_search.setGeometry(QRect(40, 160, 49, 15))
        self.line_search = QLineEdit(self.centralwidget)
        self.line_search.setObjectName(u"line_search")
        self.line_search.setGeometry(QRect(90, 150, 261, 23))
        self.line_search.setClearButtonEnabled(True)
        self.lbl_filt = QLabel(self.centralwidget)
        self.lbl_filt.setObjectName(u"lbl_filt")
        self.lbl_filt.setGeometry(QRect(600, 100, 81, 21))
        self.combo_filt = QComboBox(self.centralwidget)
        self.combo_filt.addItem("")
        self.combo_filt.setObjectName(u"combo_filt")
        self.combo_filt.setGeometry(QRect(680, 100, 201, 23))
        self.lbl_sort = QLabel(self.centralwidget)
        self.lbl_sort.setObjectName(u"lbl_sort")
        self.lbl_sort.setGeometry(QRect(600, 150, 71, 20))
        self.combo_sort = QComboBox(self.centralwidget)
        self.combo_sort.addItem("")
        self.combo_sort.addItem("")
        self.combo_sort.addItem("")
        self.combo_sort.setObjectName(u"combo_sort")
        self.combo_sort.setGeometry(QRect(680, 150, 201, 23))
        self.scrollArea = QScrollArea(self.centralwidget)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setGeometry(QRect(20, 200, 871, 351))
        self.scrollArea.setWidgetResizable(True)
        self.product_container = QWidget()
        self.product_container.setObjectName(u"product_container")
        self.product_container.setGeometry(QRect(0, 0, 869, 349))
        self.scrollArea.setWidget(self.product_container)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 900, 20))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.btn_exit.setText(QCoreApplication.translate("MainWindow", u"\u0412\u044b\u0445\u043e\u0434", None))
        self.lbl_full_name.setText(QCoreApplication.translate("MainWindow", u"\u0424\u0418\u041e", None))
        self.btn_add.setText(QCoreApplication.translate("MainWindow", u"\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c", None))
        self.btn_edit.setText(QCoreApplication.translate("MainWindow", u"\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c", None))
        self.btn_del.setText(QCoreApplication.translate("MainWindow", u"\u0423\u0434\u0430\u043b\u0438\u0442\u044c", None))
        self.lbl_search.setText(QCoreApplication.translate("MainWindow", u"\u041f\u043e\u0438\u0441\u043a:", None))
        self.line_search.setPlaceholderText(QCoreApplication.translate("MainWindow", u"\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043a\u0440\u0438\u0442\u0435\u0440\u0438\u0439 \u0434\u043b\u044f \u043f\u043e\u0438\u0441\u043a\u0430...", None))
        self.lbl_filt.setText(QCoreApplication.translate("MainWindow", u"\u0424\u0438\u043b\u044c\u0442\u0440\u0430\u0446\u0438\u044f:", None))
        self.combo_filt.setItemText(0, QCoreApplication.translate("MainWindow", u"\u0412\u0441\u0435 \u043f\u043e\u0441\u0442\u0430\u0432\u0449\u0438\u043a\u0438", None))

        self.lbl_sort.setText(QCoreApplication.translate("MainWindow", u"\u0421\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u043a\u0430:", None))
        self.combo_sort.setItemText(0, QCoreApplication.translate("MainWindow", u"\u041f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e", None))
        self.combo_sort.setItemText(1, QCoreApplication.translate("MainWindow", u"\u041f\u043e \u043a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u0443 (\u0432\u043e\u0437\u0440)", None))
        self.combo_sort.setItemText(2, QCoreApplication.translate("MainWindow", u"\u041f\u043e \u0443\u0431\u044b\u0432\u0430\u043d\u0438\u044e (\u0443\u0431\u044b\u0432)", None))

    # retranslateUi

